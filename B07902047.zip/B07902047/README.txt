Run hw3.py with python3 and it will draw the picture of Ein first and the picture of Eout second. It will probably take some time. Thank you for your patience!
